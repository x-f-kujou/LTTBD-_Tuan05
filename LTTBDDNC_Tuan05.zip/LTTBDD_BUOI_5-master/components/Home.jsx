import { useRoute } from '@react-navigation/native';
import React, { useEffect, useState } from 'react'
import { Image, Text, TouchableOpacity, View } from 'react-native'

export default function Home({ navigation }) {
    const route = useRoute();

    var blue = require('../image/xanh.png')
    var [link, setLink] = useState(blue)

    useEffect(() => {
        if (route.params != null)
            setLink(route.params.link)
    }, [route.params]);
    return (
        <View>
            <View >
                <Image style={{ width: 270, height: 325, alignSelf: 'center' }} source={link} />
                <Text style={{ textAlign: 'center', marginTop: 26, fontSize: 18 }}>Điện thoại Vsmart Joy 3 - Hàng chính hãng</Text>
                <Text style={{ textAlign: 'center', marginTop: 26, fontSize: 18 }}>Điện thoại 123</Text>
                <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                    <Text style={{ textAlign: 'center', marginTop: 26, fontSize: 18 }}>123020230d</Text>
                    <Text style={{ textAlign: 'center', marginTop: 26, marginLeft: 20, fontSize: 16, textDecorationLine: 'line-through' }}>123020230d</Text>
                </View>
            </View>
            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                <TouchableOpacity onPress={() => navigation.navigate('Detail')} style={{ width: '90%', height: 50, borderColor: '#000', borderWidth: 1, textAlign: 'center', lineHeight: 50, fontSize: 23, borderRadius: 10 }}>4 Màu - Chọn ngay</TouchableOpacity>
            </View>
            <TouchableOpacity style={{ width: '100%', height: 50, backgroundColor: 'yellow', lineHeight: 50, marginTop: 30, textAlign: 'center' }}>Mua ngay</TouchableOpacity>
        </View>
    )
}
