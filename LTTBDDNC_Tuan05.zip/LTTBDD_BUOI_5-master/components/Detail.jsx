import { useRoute } from '@react-navigation/native';
import React, { useEffect, useState } from 'react'
import { Image, TouchableOpacity, View } from 'react-native'

export default function Detail({ navigation }) {
    const title = "Điện thoại VSmart Joy 3\nHàng chính hãng"
    var phoneBlue = require('../image/xanh.png');
    var phoneSilve = require('../image/bac.png');
    var phoneRed = require('../image/do.png');
    var phoneBlack = require('../image/den.png');
    const [phone, setPhone] = useState({
        title,
        src: phoneBlue,
        price: '123.232.233đ'
    })

    const handleChangePhone = (phoneColor) => {
        setPhone({ ...phone, src: phoneColor })
    }
    return (
        <View>
            <View >
                <Image style={{ width: 200, height: 250, alignSelf: 'center' }} source={phone.src} />
            </View>
            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                <TouchableOpacity onPress={() => handleChangePhone(phoneRed)} style={{ width: 100, height: 100, backgroundColor: 'red' }}></TouchableOpacity>
                <TouchableOpacity onPress={() => handleChangePhone(phoneBlue)} style={{ width: 100, height: 100, backgroundColor: 'blue' }}></TouchableOpacity>
                <TouchableOpacity onPress={() => handleChangePhone(phoneBlack)} style={{ width: 100, height: 100, backgroundColor: 'black' }}></TouchableOpacity>
                <TouchableOpacity onPress={() => handleChangePhone(phoneSilve)} style={{ width: 100, height: 100, backgroundColor: 'gray' }}></TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => navigation.navigate("Home", { link: phone.src })} style={{ width: '100%', height: 50, backgroundColor: '#2360b6', lineHeight: 50, marginTop: 30, textAlign: 'center' }}>Chọn màu này</TouchableOpacity>
        </View>
    )
}
